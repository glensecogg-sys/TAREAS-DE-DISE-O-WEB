#Evaluación completa de estudiante:
nota_1 = float(input("Ingresa tu primer nota: "))
nota_2 = float(input("Ingresa tu segunda nota: "))
nota_3 = float(input("Ingresa tu tercer nota: "))

promedio = (nota_1 + nota_2 + nota_3)/3

print("El promedio de las tres notas es :",promedio)

if 90 <= promedio:
    print("Excelente")
elif 70 <= promedio and promedio <= 89:
    print("Bueno")
elif 60 <= promedio and promedio <= 69:
    print("Regular")
else:
    print("Reprobado")
