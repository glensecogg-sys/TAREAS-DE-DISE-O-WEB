#Calculadora basica:

# Pedir al usuario dos numeros y una operacion
num1 = int(input("ingrese el primer numero: "))
num2 = int(input("ingrese el segundo numero: "))

# Realizar el calculo segun la operacion ingresada
operacion = input("introduce una operacion (suma, resta, multiplicacion, division ): ")

if operacion == '+':
    resultado = num1 + num2
    print("El resultado de la suma es:", resultado)

elif operacion == '-':
    resultado = num1 - num2
    print("El resultado de la resta es:", resultado)

elif operacion == '*':
    resultado = num1 * num2
    print("el resultado de la multiplicacion es:", resultado)

elif operacion == '/':

# Verificar que no se divida entre cero

    if num2 != 0:
        resultado = num1 / num2
        print("el resultado de la division es:", resultado)
    else:

# Mensaje de error si la operacion no es valida

        print("Error: no se puede dividir entre cero.")
