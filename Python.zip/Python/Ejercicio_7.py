#Clasificación de triángulos:

lado1 = float(input("Inserta el primer lado"))
lado2 = float(input("Inserta el segundo  lado"))
lado3 = float(input("Inserta el tercer lado"))

if lado1 == lado2 == lado3:
    print("Es un triángulo equilátero")
elif lado1 == lado2 or lado1 == lado3 or lado2 == lado3:
    print("Es un triángulo isóceles")
else:
    print("es un triángulo escaleno")    