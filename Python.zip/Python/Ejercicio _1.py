#Número positivo o negativo:

numero = int(input ("Introduce un número"))
if numero > 0:
    print("Es positivo")
elif numero ==0:
    print("Es cero")
else:
    print("Es negativo")  
    











