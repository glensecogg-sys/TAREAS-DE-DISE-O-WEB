#Descuento de compras:

monto = int(input("Ingrese el monto total de la compra: "))

# Determinar el porcentaje de descuento según el monto
if monto > 1000:
    porcentaje_descuento = 20  # 30%
elif monto >500 and monto >1000:
    porcentaje_descuento = 10  # 10%
else:
    porcentaje_descuento = 0

# Calcular el monto del descuento y el total a pagar
monto_descuento = monto * porcentaje_descuento // 100  # Usamos // para división entera
total_pagar = monto - monto_descuento

# Mostrar los resultados
print(f"Monto original: {monto}")
print(f"Porcentaje de descuento: {porcentaje_descuento}%")
print(f"Total a pagar después del descuento: {total_pagar}")
