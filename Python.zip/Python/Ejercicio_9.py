#Tarifa de transporte:
edad = int(input ("Introduce tu edad"))

if edad <5:
    precio = "Gratis"

elif 5 <= edad and edad <= 18:
    precio = "L10" 

elif  19 <= edad and edad <=60:
    precio = "L20"

else:
    precio = "L15" 

print("Su precio de transporte es:",precio)             
