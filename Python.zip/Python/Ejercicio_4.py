#Clasificación de nota:

nota = int(input("Ingresa tu nota: "))

if 90 <= nota and nota <= 100:
    print("Excelente")
elif 70 <= nota and nota <= 89:
    print("Bueno")
elif 60 <= nota and nota <= 69:
    print("Regular")
else:
    print("Reprobado")
