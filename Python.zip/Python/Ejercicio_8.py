#Simulación de un login:
usuario_correcto = "admin"
contraseña_correcta = "1234"

oportunidades = 0
oportunidades_limite = 3

while oportunidades < oportunidades_limite:
    usuario = input("Ingrese su usuario: ")
    contraseña = input("Ingrese su contraseña: ")

    if usuario == usuario_correcto and contraseña == contraseña_correcta:
        print("Acceso concedido")
        break
    else:
        oportunidades += 1
        oportunidades_restantes = oportunidades_limite - oportunidades
        print("Datos incorrectos")

        if oportunidades_restantes > 0:
            print("Te quedan",oportunidades_restantes,"oportunidades")
        else:
            print("Has agotado tus intentos")
 
